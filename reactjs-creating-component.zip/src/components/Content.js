import React from "react";
function Content() {
  var name = "sara";
  var pStyles = {
    color: "green",
    fontSize: 14
  };
  return (
    <div>
      <h1>Hello {name}!</h1>
      <p style={pStyles}>Welcome to ReactJs tutorial</p>
    </div>
  );
}
export default Content;
