import React from "react";
function Header() {
  return (
    <div>
      <h1 className="header">Header Section</h1>
    </div>
  );
}
export default Header;
