import React from "react";
function Footer() {
  return (
    <div>
      <h1 className="footer">Footer Section</h1>
    </div>
  );
}
export default Footer;
